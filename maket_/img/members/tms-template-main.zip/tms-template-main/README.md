# TMS Project Template

Use this structure for basic markup with HTML+SCSS


## Main commands

**npm start**

Begin development prosses by starting your project. Default path to open is ```localhost:3000```

**npm run build**

Precompile you project before publishing.
